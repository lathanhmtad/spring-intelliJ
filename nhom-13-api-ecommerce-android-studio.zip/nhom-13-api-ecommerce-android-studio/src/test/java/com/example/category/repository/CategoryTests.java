package com.example.category.repository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Configuration;

import com.example.entity.Cart;
import com.example.entity.Product;
import com.example.repository.CartRepository;
import com.example.repository.ProductRepository;

@SpringBootTest
@Configuration
public class CategoryTests {

	@Autowired
	ProductRepository productRepository;
	@Autowired CartRepository cartRepository;
	
//	@Test
//	void getCategoryByIdTest() {
//		Category cate = categoryRepository.findById(1).get();
//		System.out.println(cate);
////		List<Product> prs = productRepository.findAllByCategory_Id(1);
////		cate.getProducts().stream().forEach(p->System.out.println(p));
//	}
	
	@Test
	void test() {
		Cart c = new Cart();
		c.setIdProduct(1);
		c.setIdUser(1);
		cartRepository.save(c);
	}
	
}
