package com.example.service;

import java.util.List;

import com.example.dto.CartDTO;

public interface ICartService {
	List<CartDTO> getCart(Integer idUser);
	CartDTO addToCart (Integer idUser, Integer idProduct);
	void updateQuantity(Short quantity, Integer idUser, Integer idProduct);
	void deleteCart(Integer[] ids);
}
