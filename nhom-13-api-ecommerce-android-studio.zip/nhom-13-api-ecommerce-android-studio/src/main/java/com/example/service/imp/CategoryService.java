package com.example.service.imp;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dto.CategoryDTO;
import com.example.entity.Category;
import com.example.repository.CategoryRepository;
import com.example.service.ICategoryService;
@Service
public class CategoryService implements ICategoryService{
	@Autowired
	private CategoryRepository categoryRepository;
	@Autowired
	private ModelMapper modelMapper;
	@Override
	public List<CategoryDTO> findAll() {
		// TODO Auto-generated method stub
		List<CategoryDTO> categoryDTOs = new ArrayList<>();
		List<Category> categories = categoryRepository.findAll();
		for (Category category : categories) {
			categoryDTOs.add(modelMapper.map(category, CategoryDTO.class));
		}
		return categoryDTOs;
	}

}
