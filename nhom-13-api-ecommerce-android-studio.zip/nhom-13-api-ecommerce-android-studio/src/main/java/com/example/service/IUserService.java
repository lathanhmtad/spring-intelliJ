package com.example.service;

import com.example.dto.UserDTO;

public interface IUserService {
	UserDTO Save(UserDTO dto);
	UserDTO findOne(String email,String password);
}
