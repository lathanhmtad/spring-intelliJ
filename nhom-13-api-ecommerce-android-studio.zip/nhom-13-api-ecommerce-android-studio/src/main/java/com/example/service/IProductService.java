package com.example.service;

import java.util.List;
import com.example.dto.ProductDTO;

public interface IProductService {
	List<ProductDTO> findAll(Integer id);
	ProductDTO Save(ProductDTO product);
	void delete(Integer[] ids);
	List<ProductDTO> findAllByCategory(Integer id);
}
