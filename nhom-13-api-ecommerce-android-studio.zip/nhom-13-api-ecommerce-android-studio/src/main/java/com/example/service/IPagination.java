package com.example.service;

import com.example.dto.Pagination;
import com.example.dto.ProductDTO;

public interface IPagination {
	Pagination<ProductDTO> paginationForProduct(Integer page,Integer limit);
}
