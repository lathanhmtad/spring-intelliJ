package com.example.service.imp;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dto.CartDTO;
import com.example.entity.Cart;
import com.example.entity.Product;
import com.example.repository.CartRepository;
import com.example.repository.ProductRepository;
import com.example.service.ICartService;

import jakarta.transaction.Transactional;
@Service
public class CartService implements ICartService{
	@Autowired
	private CartRepository cartRepository;
	@Autowired
	private ProductRepository productRepository;
	@Autowired
	private ModelMapper modelMapper;
	@Override
	public List<CartDTO> getCart(Integer idUser) {
		List<Cart> carts = cartRepository.findByIdUser(idUser);
		List<CartDTO> cartDtos = new ArrayList<>();
		for (Cart c : carts) {
			cartDtos.add(modelMapper.map(c, CartDTO.class));
		}
		return cartDtos;
	}
	@Transactional
	@Override
	public CartDTO addToCart(Integer idUser, Integer idProduct) {
		Cart cartOld = cartRepository.findByIdUserAndIdProduct(idUser, idProduct);
		if(cartOld!=null) {
			cartOld.setQuantity((short)(cartOld.getQuantity()+1));	
			cartOld.setPrice(cartOld.getPrice().add(cartOld.getPrice()));
			return modelMapper.map(cartRepository.save(cartOld), CartDTO.class);
		}else {
			Cart cart =  new Cart();
			Product product = productRepository.findById(idProduct).get();
			cart.setIdUser(idUser);
			cart.setIdProduct(idProduct);
			cart.setQuantity((short)1);
			cart.setName(product.getName());
			cart.setPrice(product.getPrice());
			cartRepository.save(cart);
			return modelMapper.map(cart, CartDTO.class);
		}
	}
	@Transactional
	@Override
	public void updateQuantity(Short quantity, Integer idUser, Integer idProduct) {
		Product product = productRepository.findById(idProduct).get();
		Cart cartOld = cartRepository.findByIdUserAndIdProduct(idUser, idProduct);
		cartOld.setQuantity(quantity);
		cartOld.setPrice(product.getPrice().multiply(BigDecimal.valueOf(quantity)));
		cartRepository.save(cartOld);
	}
	@Override
	public void deleteCart(Integer[] ids) {
		// TODO Auto-generated method stub
		for (int i=0;i<ids.length;i++) {
			cartRepository.deleteById(ids[i]);
		}
	}
}
