package com.example.service.imp;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.example.dto.ProductDTO;
import com.example.entity.Category;
import com.example.entity.Product;
import com.example.repository.CategoryRepository;
import com.example.repository.ProductRepository;
import com.example.service.IProductService;
@Service
public class ProductService implements IProductService{
	@Autowired
	private ProductRepository productRepository;
	@Autowired
	private ModelMapper modelMapper;
	@Autowired
	private CategoryRepository categoryRepository;
	@Override
	public List<ProductDTO> findAll(Integer id) {
		List<ProductDTO> productsDTO = new ArrayList<>();
		if(id!=null) {
			productsDTO.add(modelMapper.map(productRepository.findById(id).get(), ProductDTO.class));
		}else {
			List<Product> products = productRepository.findAll();
			for (Product product : products) {
				productsDTO.add(modelMapper.map(product, ProductDTO.class));
			}
		}
		return productsDTO;
	}
	@Override
	@Transactional
	public ProductDTO Save(ProductDTO dto) {
		Category category = categoryRepository.findById(dto.getCategoryId()).get();
		Product newProduct = new Product();
		if(dto.getId()!=null) {
			Product oldProduct = productRepository.findById(dto.getId()).get();
			oldProduct = modelMapper.map(dto, Product.class);
			oldProduct.setCategory(category);
			return modelMapper.map(productRepository.save(oldProduct), ProductDTO.class); 
		}else {
			newProduct = modelMapper.map(dto, Product.class);
			newProduct.setCategory(category);
			return modelMapper.map(productRepository.save(newProduct), ProductDTO.class); 
		}
	}
	@Override
	@Transactional
	public void delete(Integer[] ids) {
		for(int i=0;i<ids.length;i++) {
			productRepository.deleteById(ids[i]);
		}
	}
	@Override
	public List<ProductDTO> findAllByCategory(Integer id) {
		Category cate = categoryRepository.findById(id).get();
		List<Product> prs = cate.getProducts();
		List<ProductDTO> prdto = new ArrayList<>();
		for (Product pr : prs) {
			prdto.add(modelMapper.map(pr, ProductDTO.class));
		}
		return prdto;
	}
}
