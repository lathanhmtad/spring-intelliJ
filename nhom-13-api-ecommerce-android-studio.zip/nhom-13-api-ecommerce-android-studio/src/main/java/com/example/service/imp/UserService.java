package com.example.service.imp;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dto.UserDTO;
import com.example.entity.Role;
import com.example.entity.User;
import com.example.repository.RoleRepository;
import com.example.repository.UserRepository;
import com.example.service.IUserService;
@Service
public class UserService implements IUserService{
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private RoleRepository roleRepository;
	@Autowired
	private ModelMapper modelMapper;
	@Override
	public UserDTO Save(UserDTO dto) {
		Role role = roleRepository.findById(dto.getRoleId()).get();
		User newUser = new User();
		if(dto.getId()!=null) {
			User oldUser = userRepository.findById(dto.getId()).get();
			oldUser = modelMapper.map(dto, User.class);
			oldUser.setRole(role);
			return modelMapper.map(userRepository.save(oldUser), UserDTO.class); 
		}else {
			newUser = modelMapper.map(dto, User.class);
			newUser.setRole(role);
			return modelMapper.map(userRepository.save(newUser), UserDTO.class); 
		}
	}
	@Override
	public UserDTO findOne(String email, String password) {
		// TODO Auto-generated method stub
		return modelMapper.map(userRepository.findOneByEmailAndPassword(email, password), UserDTO.class);
	}
}
