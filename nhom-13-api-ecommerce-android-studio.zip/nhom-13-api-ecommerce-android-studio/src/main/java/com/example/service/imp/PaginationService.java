package com.example.service.imp;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.example.dto.Pagination;
import com.example.dto.ProductDTO;
import com.example.entity.Product;
import com.example.repository.ProductRepository;
import com.example.service.IPagination;
@Service
public class PaginationService implements IPagination{
	@Autowired
	private ProductRepository productRepository;
	@Autowired
	private ModelMapper modelMapper;
	@Override
	public Pagination<ProductDTO> paginationForProduct(Integer page,Integer limit) {
		Pagination<ProductDTO> pg = new Pagination<>();
		List<Product> prs = productRepository.findAll(PageRequest.of(page-1, limit)).getContent();
		List<ProductDTO> prdto = new ArrayList<>();
		for (Product product : prs) {
			prdto.add(modelMapper.map(product, ProductDTO.class));
		}
		pg.setListResult(prdto);
		pg.setTotalItem((int)productRepository.count());
		pg.setLimit(limit);
		pg.setPage(page);
		pg.setTotalPage((int) Math.ceil((double) pg.getTotalItem() / pg.getLimit()));
		return pg;
	}

}
