package com.example.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.dto.CartDTO;
import com.example.service.imp.CartService;

@RestController
public class CartAPI {
	@Autowired
	private CartService cartService;
	@GetMapping("/api/cart/{idCart}")
	public List<CartDTO> getCart(@PathVariable("idCart") Integer id){
		return cartService.getCart(id);
	}
	@PostMapping("/api/cart")
	public CartDTO addToCart(@RequestBody CartDTO dto) {
		return cartService.addToCart(dto.getIdUser(), dto.getIdProduct());
	}
	@PutMapping("/api/cart")
	public void updateQuantity(@RequestBody CartDTO dto) {
		cartService.updateQuantity(dto.getQuantity(), dto.getIdUser(), dto.getIdProduct());
	}
	@DeleteMapping("/api/cart")
	public void deleteCart(@RequestBody CartDTO dto) {
		cartService.deleteCart(dto.getIds());
	}
}
