package com.example.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;

import com.example.entity.Product;

public class Test {
	
	
	public static void main(String[] args) {
	}
}
